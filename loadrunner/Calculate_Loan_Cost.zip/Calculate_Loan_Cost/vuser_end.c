
/*
    PowerTerm(R) for HP Performance Software for Windows XP/2003/2008/7/2008 R2/8/2012
    Version: 10.2.0
    Copyright (C) 1994-2014 Ericom(R) Software
*/

vuser_end()
{
      return 0;
}

